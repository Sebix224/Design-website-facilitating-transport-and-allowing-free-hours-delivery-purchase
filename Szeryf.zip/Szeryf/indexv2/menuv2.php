<!Doctype Html>
<html lang="pl">
    <header>
        <title>Strona startowa</title>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="aa.css">
    </header>
    <body>
        <div id="kontener">
            <div id="t">
                <img src="../imagine/Gen1.png">
            </div>
             <div id="l">
                 <a href="login/rejestracja_test.php"><input type="button" id="lp" value="Rejestracja"></a>
            </div>
            <div id="p">
                <a href="login/login.html"> <input type="button" id="pp" value="Zaloguj się"> </a>
            </div>
           
        </div>
    </body>
</html>