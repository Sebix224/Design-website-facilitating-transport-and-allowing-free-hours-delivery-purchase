<?PHP
	session_start();
	
	if (isset($_POST['email']))
	{
		
		$wszystko_OK=true;
		
		$nick = $_POST['nick'];
		
		//Sprawdzenie długości nicka
		if ((strlen($nick)<3) || (strlen($nick)>20))
		{
			$wszystko_OK=false;
			$_SESSION['e_nick']='<div style="color:red;text-align:center;">Nazwa musi posiadać od 3 do 20 znaków!</div>';
		}
		
		if (ctype_alnum($nick)==false)
		{
			$wszystko_OK=false;
			$_SESSION['e_nick']='<div style="color:red;text-align:center;">Nazwa może składać się tylko z liter i cyfr (bez polskich znaków)</div>';
		}
		
		// Sprawdź poprawność adresu email
		$email = $_POST['email'];
		$emailB = filter_var($email, FILTER_SANITIZE_EMAIL);
		
		if ((filter_var($emailB, FILTER_VALIDATE_EMAIL)==false) || ($emailB!=$email))
		{
			$wszystko_OK=false;
			$_SESSION['e_email']='<div style="color:red;text-align:center;";text-align:center;>Podaj poprawny adres e-mail!</div>';
		}
		
		//Sprawdź poprawność hasła

		$haslo = $_POST['haslo'];
	
		if ((strlen($haslo)<8) || (strlen($haslo)>20))
		{
			$wszystko_OK=false;
			$_SESSION['e_haslo']='<div style="color:red;text-align:center;">Hasło musi posiadać od 8 do 20 znaków!</div>';
		}
		
		//$haslo_hash = password_hash($haslo, PASSWORD_DEFAULT);
		//Sprawdź czy jest kod
		if ($_POST['kod']=="")
		{
			$wszystko_OK=false;
			$_SESSION['e_kod']='<div style="color:red;text-align:center;">Kod pocztowy jest wymagany!</div>';
		}	
		
		//Sprawdź czy jest m
		if ($_POST['miejscowosc']=="")
		{
			$wszystko_OK=false;
			$_SESSION['e_miejscowosc']='<div style="color:red;text-align:center;">Miejscowość wpisz!</div>';
		}
		
		//Sprawdź czy jest u
		if ($_POST['ulica']=="")
		{
			$wszystko_OK=false;
			$_SESSION['e_ulica']='<div style="color:red;text-align:center;">Brak nazwy ulicy!</div>';
		}
		
		//Sprawdź czy jest numer
		if ($_POST['numer']=="")
		{
			$wszystko_OK=false;
			$_SESSION['e_numer']='<div style="color:red;text-align:center;">Brak numeru!</div>';
		}
		
		//Czy wiek +18?
		if (!isset($_POST['wiek']))
		{
			$wszystko_OK=false;
			$_SESSION['e_wiek']='<div style="color:red;text-align:center;">Masz mniej niż 18 lat!</div>';
		}	
		
		//Czy zaakceptowano regulamin?
		if (!isset($_POST['regulamin']))
		{
			$wszystko_OK=false;
			$_SESSION['e_regulamin']='<div style="color:red;text-align:center;">Potwierdź akceptację regulaminu!</div>';
		}				
				
		//Zapamiętaj wprowadzone dane
		$kod = htmlentities($_POST['kod'], ENT_QUOTES, "UTF-8");
		$miejscowosc = htmlentities($_POST['miejscowosc'], ENT_QUOTES, "UTF-8");
		$ulica = htmlentities($_POST['ulica'], ENT_QUOTES, "UTF-8");
		$numer = htmlentities($_POST['numer'], ENT_QUOTES, "UTF-8");
		
		
		$_SESSION['fr_nick'] = $nick;
		$_SESSION['fr_email'] = $email;
		$_SESSION['fr_haslo'] = $haslo;
		$_SESSION['fr_kod'] = $kod;
		$_SESSION['fr_miejscowosc'] = $miejscowosc;
		$_SESSION['fr_ulica'] = $ulica;
		$_SESSION['fr_numer'] = $numer;
		
	if (isset($_POST['regulamin'])) {$_SESSION['fr_regulamin'] = true;}
		
		
		mysqli_report(MYSQLI_REPORT_STRICT);
		
		try 
		{
			require_once"connect_base.php";
			$polaczenie = new mysqli($host, $db_user, $db_password, $db_name);
			if ($polaczenie->connect_errno!=0)
			{
				throw new Exception(mysqli_connect_errno());
			}
			else
			{
				
				//Czy email już istnieje?
				$rezultat = $polaczenie->query("SELECT id_uzytkownika FROM uzytkownicy WHERE email='$email'");
				
				if (!$rezultat) throw new Exception($polaczenie->error);
				
				$ile_takich_maili = $rezultat->num_rows;
				if($ile_takich_maili>0)
				{
					$wszystko_OK=false;
					$_SESSION['e_email']='<div style="color:red;text-align:center;">Istnieje już konto przypisane do tego adresu e-mail!</div>';
				}		
				
				//Czy nick jest już zarezerwowany?
				$rezultat = $polaczenie->query("SELECT id_uzytkownika FROM uzytkownicy WHERE user='$nick'");
				
				if (!$rezultat) throw new Exception($polaczenie->error);
				
				$ile_takich_nickow = $rezultat->num_rows;
				if($ile_takich_nickow>0)
				{
					$wszystko_OK=false;
					$_SESSION['e_nick']='<div style="color:red;text-align:center;">Istnieje już użytkownik o takiej nazwie! Wybierz inną.</div>';
				}
				
				if ($wszystko_OK==true)
				{
					//Hurra, wszystkie testy zaliczone, dodajemy gracza do bazy
					
					if ($polaczenie->query("INSERT INTO uzytkownicy VALUES (NULL, '$nick', '$haslo', '$email', '$kod', '$miejscowosc', '$ulica', '$numer')"))
					{
						$_SESSION['udanarejestracja']=true;
						header('Location: http://localhost/szeryf/przejscie/przejsciev2/p2.php');
					}
					else
					{
						throw new Exception($polaczenie->error);
					}
					
				}
				
				$polaczenie->close();
			}
			
		}
		catch(Exception $e)
		{
			echo '<div style="color:red;text-align:center;">Błąd serwera! Przepraszamy za niedogodności i prosimy o rejestrację w innym terminie!</div>';
			echo '<div style="color:red;text-align:center">Informacja developerska: '.$e.'</div>';
		}
		
	}
?>
<!Doctype Html>
<html lang="pl">
    <head>
        <title>Rejestracja</title>
        <meta charset="UTF-8">
       <!----> <link rel="stylesheet" type="text/css" href="r.css">
    </head>
    <body>
		<div id="kontener">
			<form method="post">

				<label>Proszę podać nazwe użytkownika:</label>
				<input type="text" value="<?php
				if (isset($_SESSION['fr_nick']))
				{
					echo $_SESSION['fr_nick'];
					unset($_SESSION['fr_nick']);
				}
				?>" name="nick"/>
				<?php
				if (isset($_SESSION['e_nick']))
				{
					echo $_SESSION['e_nick'];
					unset($_SESSION['e_nick']);
				}
				?>
				
				<label>Proszę podać e-mail:</label>
				<input type="email" value="<?php
				if (isset($_SESSION['fr_email']))
				{
					echo $_SESSION['fr_email'];
					unset($_SESSION['fr_email']);
				}
				?>"name="email"/>
				<?php
				if (isset($_SESSION['e_email']))
				{
					echo $_SESSION['e_email'];
					unset($_SESSION['e_email']);
				}
				?>
				
				<label>Proszę podać hasło:</label>
				<input type="password" value="<?php
				if (isset($_SESSION['fr_haslo']))
				{
					echo $_SESSION['fr_haslo'];
					unset($_SESSION['fr_haslo']);
				}
				?>"name="haslo"/>
				
				<?php
					if (isset($_SESSION['e_haslo']))
					{
						echo $_SESSION['e_haslo'];
						unset($_SESSION['e_haslo']);
					}
				?>	
				
				<label>Proszę podać kod pocztowy:</label>
				<input type="text" value="<?php
				if (isset($_SESSION['fr_kod']))
				{
					echo $_SESSION['fr_kod'];
					unset($_SESSION['fr_kod']);
				}
				?>"name="kod"/>
				<?php
					if (isset($_SESSION['e_kod']))
					{
						echo $_SESSION['e_kod'];
						unset($_SESSION['e_kod']);
					}
				?>
				<label>Proszę podać miejscowość:</label>
				<input type="text" value="<?php
				if (isset($_SESSION['fr_miejscowosc']))
				{
					echo $_SESSION['fr_miejscowosc'];
					unset($_SESSION['fr_miejscowosc']);
				}
				?>"name="miejscowosc"/>
				<?php
					if (isset($_SESSION['e_miejscowosc']))
					{
						echo $_SESSION['e_miejscowosc'];
						unset($_SESSION['e_miejscowosc']);
					}
				?>
				<label>Proszę podać ulice:</label>
				<input type="text" value="<?php
				if (isset($_SESSION['fr_ulica']))
				{
					echo $_SESSION['fr_ulica'];
					unset($_SESSION['fr_ulica']);
				}
				?>"name="ulica"/>
				<?php
					if (isset($_SESSION['e_ulica']))
					{
						echo $_SESSION['e_ulica'];
						unset($_SESSION['e_ulica']);
					}
				?>
				<label>Proszę podać numer domu:</label>
				<input type="text" value="<?php
				if (isset($_SESSION['fr_numer']))
				{
					echo $_SESSION['fr_numer'];
					unset($_SESSION['fr_numer']);
				}
				?>"name="numer"/>
				<?php
					if (isset($_SESSION['e_numer']))
					{
						echo $_SESSION['e_numer'];
						unset($_SESSION['e_numer']);
					}
				?>
				<!--wiek checkbox-->
				<label>Proszę potwierdzić ukończenie 18 roku życia:</label>
				<input type="checkbox" value="<?php
				if (isset($_SESSION['fr_wiek']))
				{
					echo $_SESSION['fr_wiek'];
					unset($_SESSION['fr_wiek']);
				}
				?>"name="wiek" class="reg"/>
				<?php
				if (isset($_SESSION['e_wiek']))
				{
					echo $_SESSION['e_wiek'];
					unset($_SESSION['e_wiek']);
				}
				?>
				<!--regulamin checkbox + odnośnik do regulaminu-->
				<label>Proszę zaakceptować regulamin:</label>
				<a href="" class="reg">Kliknij aby przeczytać regulamin</a>
				<input type="checkbox" name="regulamin" class="reg"/>
				<?php
				if (isset($_SESSION['e_regulamin']))
				{
					echo $_SESSION['e_regulamin'];
					unset($_SESSION['e_regulamin']);
				}
				?>
				
                <input type="submit" value="Zatwierdź" /><a href="../../przejscie/przejsciev2/p2.html"></a>

			</form>
		</div>
    </body>
</html>