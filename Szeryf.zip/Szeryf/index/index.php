<!Doctype Html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="i.css">
        <title>Start</title>
    </head>
    <body>
        <div id="kont">
            <div id="napis">
                <h1>Witamy w Automacie Autlo-Liquid</h1>
            </div>
            <div id="a">
                <a href="../indexv2/menuv2.php"><img src="../imagine/GGen.png"></a>
            </div>
        </div>
    </body>
</html>
