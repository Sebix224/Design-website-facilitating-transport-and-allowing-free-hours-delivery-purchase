<!Doctype Html>
<html lang="pl">
    <header>
        <title>Strona końcow</title>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="b.css">
    </header>
    <body>
        <div id="kontener">
           <div id="tyt">
               <h1> Dziękujemy za zakupy i zapraszamy ponownie</h1>
            </div>
            <div id="pa">
                <a href="../indexv2/login/wyloguj.php"><img src="../imagine/GGen.png"></a><br>       
            </div>
        </div>
    </body>
</html>