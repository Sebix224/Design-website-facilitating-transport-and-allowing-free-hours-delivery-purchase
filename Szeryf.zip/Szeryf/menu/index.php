<?php
        session_start();
		if (isset($_POST['button1'])){
			 $_SESSION['wielkosc']='10ml';
			 $_SESSION['cena']=20.00;
			 header('Location: http://localhost/szeryf/10ml/10ml.php');
			 exit();
        }
        else if(isset($_POST['button2'])) {
			 $_SESSION['wielkosc']='20ml';
			 $_SESSION['cena']=39.50;
			 header('Location: http://localhost/szeryf/10ml/10ml.php');
			 exit();
        }
		else if(isset($_POST['button3'])) {
			 $_SESSION['wielkosc']='50ml';
			 $_SESSION['cena']=70.00;
			 header('Location: http://localhost/szeryf/10ml/10ml.php');
			 exit();
        }
			 
?>
<!Doctype Html>
<html lang="pl">
    <header>
        <title>Strona startowa</title>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="style1.css">
    </header>
    <body>
        <div id="kontener" >
            <div id="t">
                <div id="logo">
                    <img src="../imagine/Gen1.png">
                </div>
                <div id="tyt">
                    <h1>Wybierz wielkość butelki!</h1>
                </div>
            </div>
            <div id="coon">
                <div id="butelkii">
                    <img id="100" class="but" src=1110ml.png>
                    <img id="200" class="but" src=220ml.png>
                    <img id="500" class="but" src=550ml.png>
                </div>			
				<form method='post'>
					<div id="przyciski">
						<input type="submit" name="button1" id="10" class="guzik" value="10ml-20,00zł" />
						
						<input type="submit" name="button2" id="10" class="guzik" value="20ml-39,50zł" />
						
						<input type="submit" name="button3" id="10" class="guzik" value="50ml-70,00zł" />		
					</div>
                </form>	
            </div>
        </div>      
    </body>
</html>

