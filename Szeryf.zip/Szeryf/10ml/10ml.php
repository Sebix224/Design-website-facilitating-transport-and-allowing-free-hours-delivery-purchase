<?php 
	session_start();
	function przenies(){header('Location:http://localhost/szeryf/zakupy/zakupy.php');  exit();}
	if (isset($_POST['Ananas'])){$_SESSION['smak']='Ananas';przenies();}
	else if (isset($_POST['Arbuz'])){$_SESSION['smak']='Arbuz';przenies();}
	else if (isset($_POST['Banan'])){$_SESSION['smak']='Banan';przenies();}
	else if (isset($_POST['Borówka'])){$_SESSION['smak']='Borówka';przenies();}
	else if (isset($_POST['Brzoskwinia'])){$_SESSION['smak']='Brzoskwinia';przenies();}
	else if (isset($_POST['Cytryna'])){$_SESSION['smak']='Cytryna';przenies();}
	else if (isset($_POST['Czarna pożeczka'])){$_SESSION['smak']='Czarna pożeczka';przenies();}
	else if (isset($_POST['Czekolada'])){$_SESSION['smak']='Czekolada';przenies();}
	else if (isset($_POST['Dynia'])){$_SESSION['smak']='Dynia';przenies();}
	else if (isset($_POST['Gruszka'])){$_SESSION['smak']='Gruszka';przenies();}
	else if (isset($_POST['Jabłko'])){$_SESSION['smak']='Jabłko';przenies();}
	else if (isset($_POST['Kaktus'])){$_SESSION['smak']='Kaktus';przenies();}
	else if (isset($_POST['Karmel'])){$_SESSION['smak']='Karmel';przenies();}
	else if (isset($_POST['Kiwi'])){$_SESSION['smak']='Kiwi';przenies();}
	else if (isset($_POST['Liczi'])){$_SESSION['smak']='Liczi';przenies();}
	else if (isset($_POST['Limonka'])){$_SESSION['smak']='Limonka';przenies();}
	else if (isset($_POST['Mango'])){$_SESSION['smak']='Mango';przenies();}
	else if (isset($_POST['Malina'])){$_SESSION['smak']='Malina';przenies();}
	else if (isset($_POST['Mięta'])){$_SESSION['smak']='Mięta';przenies();}
	else if (isset($_POST['Papaja'])){$_SESSION['smak']='Papaja';przenies();}
	else if (isset($_POST['Pomarańcza'])){$_SESSION['smak']='Pomarańcza';przenies();}
	else if (isset($_POST['Pigwa'])){$_SESSION['smak']='Pigwa';przenies();}
	else if (isset($_POST['Rabarbar'])){$_SESSION['smak']='Rabarbar';przenies();}
	else if (isset($_POST['Szarlotka'])){$_SESSION['smak']='Szarlotka';przenies();}
	else if (isset($_POST['Tytoń'])){$_SESSION['smak']='Tytoń';przenies();}
	else if (isset($_POST['Truskawka'])){$_SESSION['smak']='Truskawka';przenies();}
	else if (isset($_POST['Wiśnia'])){$_SESSION['smak']='Wiśnia';przenies();}
	else if (isset($_POST['Żurawina'])){$_SESSION['smak']='Żurawina';przenies();}
?>

<!Doctype Html>
<html lang="pl">
    <head>
        <title> Wybór samku </title>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="a.css">
    </head>
    <body>
        <div id="kontener">
            <div id="ty">
                <div id="logo">
                    <img src="../imagine/Gen10.png">
                </div>
                <div id="text">
                    <br>
                    <h1>Teraz wybierz smak</h1>
                </div>
                
            </div>
			<form method='post'>
				<div id="smak">
					<button type="submit" id="button" class="button" name="Ananas">Ananas</button>
					<button type="submit" id="button" class="button" name="Arbuz">Arbuz</button>
					<button type="submit" id="button" class="button" name="Banan">Banan</button>
					<button type="submit" id="button" class="button" name="Borówka">Borówka</button>
					<button type="submit" id="button" class="button" name="Brzoskwinia">Brzoskwinia</button>
					<button type="submit" id="button" class="button" name="Cytryna">Cytryna</button>
					<button type="submit" id="button" class="button" name="Czarna pożeczka">Czarna pożeczka</button>
					<button type="submit" id="button" class="button" name="Czekolada">Czekolada</button>
					<button type="submit" id="button" class="button" name="Dynia">Dynia</button>
					<button type="submit" id="button" class="button" name="Gruszka">Gruszka</button>
					<button type="submit" id="button" class="button" name="Jabłko">Jabłko</button>
					<button type="submit" id="button" class="button" name="Kaktus">Kaktus</button>
					<button type="submit" id="button" class="button" name="Karmel">Karmel</button>
					<button type="submit" id="button" class="button" name="Kiwi">Kiwi</button>
					<button type="submit" id="button" class="button" name="Liczi">Liczi</button>
					<button type="submit" id="button" class="button" name="Limonka">Limonka</button>
					<button type="submit" id="button" class="button" name="Mango">Mango</button>
					<button type="submit" id="button" class="button" name="Malina">Malina</button>
					<button type="submit" id="button" class="button" name="Mięta">Mięta</button>
					<button type="submit" id="button" class="button" name="Papaja">Papaja</button>
					<button type="submit" id="button" class="button" name="Pomarańcza">Pomarańcza</button>
					<button type="submit" id="button" class="button" name="Pigwa">Pigwa</button>
					<button type="submit" id="button" class="button" name="Rabarbar">Rabarbar</button>
					<button type="submit" id="button" class="button" name="Szarlotka">Szarlotka</button>
					<button type="submit" id="button" class="button" name="Tytoń">Tytoń</button>
					<button type="submit" id="button" class="button" name="Truskawka">Truskawka</button>
					<button type="submit" id="button" class="button" name="Wiśnia">Wiśnia</button>
					<button type="submit" id="button" class="button" name="Żurawina">Żurawina</button>
				</div>
			</form>
        </div>
    </body>
</html>
