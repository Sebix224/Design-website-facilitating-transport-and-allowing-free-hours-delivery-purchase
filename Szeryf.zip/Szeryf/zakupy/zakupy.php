<?PHP session_start();?>
<!Doctype Html>
<html lang="pl">
    <header>
        <title>Podsumowanie</title>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="zakupy.css">		
    </header>
    <body>
        <div id="kontener">
           <div id="tyt">
               <h1>Podsumowanie zakupów</h1>
            </div>
            <div id="pa">
			<form method="post">
			<?PHP
			$suma=10+$_SESSION['cena'];
			echo' <div id=tekst>Smak: '.$_SESSION['smak'].'<br> Wielkosc: '.$_SESSION['wielkosc'].'<br>Koszt dostawy: 10.00zł <br>Koszt całkowity:'.$suma.'zł</div>';
			if(isset($_POST['zakupuje'])){
				
				require_once 'connect.php';
				
				$poloczenie=new mysqli($host,$db_user,$db_password,$db_name);
				
				if ($poloczenie->connect_error) {
				  die("Connection failed: " . $poloczenie->connect_error);
				}else {
					 $wielkosc=$_SESSION['wielkosc'];
					 $smak=$_SESSION['smak'];
					 $haslo=$_SESSION['haslo'];
					 $login=$_SESSION['login'];
					 $result=$poloczenie->query("SELECT id_uzytkownika FROM uzytkownicy WHERE user='$login' AND pass='$haslo' ");
					 $row=$result->fetch_assoc();
					 $id=$row['id_uzytkownika'];
					 $result->free_result();
					 $poloczenie->query("INSERT INTO zamowienia VALUES (NULL, '$id', '$wielkosc', '$smak', 10.00, '$suma')");
					 $poloczenie->close();
				}
				header('Location: http://localhost/szeryf/end/end.php');
				exit();
			}
			if(isset($_POST['anuluj'])){
				header('Location: http://localhost/szeryf/indexv2/login/wyloguj.php');
				exit();
			}
			 
			?>
			<button type="submit" class="button" name="zakupuje">Potwierdź zakup</button>
            <button type="submit" class="button" name="anuluj">Anuluj zakup</button>  
			</form>
            </div>
        </div>
    </body>
</html>