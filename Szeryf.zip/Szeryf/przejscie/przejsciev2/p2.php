<!Doctype Html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="rr.css">
        <title>Start</title>
    </head>
    <body>
        <div id="kont">
            <div id="napis">
                <h1>Dziękujemy za rejsetracje</h1>
            </div>
            <div id="a">
                <a href="../../indexv2/login/login.html"><img src="../../imagine/GGen.png"></a>
            </div>
        </div>
    </body>
</html>
