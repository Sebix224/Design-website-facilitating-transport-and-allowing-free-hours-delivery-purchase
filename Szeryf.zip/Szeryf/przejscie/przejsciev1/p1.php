<!Doctype Html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="ii.css">
        <title>Start</title>
    </head>
    <body>
        <div id="kont">
            <div id="napis">
                <h1>Witamy w Automacie Autlo-Liquid</h1>
            </div>
            <div id="a">
                <a href="../../menu/index.php"><img src="../../imagine/GGen.png"></a>
            </div>
        </div>
    </body>
</html>